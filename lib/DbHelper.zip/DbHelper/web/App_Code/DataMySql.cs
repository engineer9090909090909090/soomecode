﻿using System;
using System.Collections.Generic;
using System.Web;
using www.dbhelper.org.SqlHelper;
using System.Data;
using MySql.Data.MySqlClient;

public class DataMySql : IDataProvider
{
    public System.Data.DataTable ReadStudent()
    {
        using (MySqlHelper helper = new MySqlHelper())
        {
            helper.Command.CommandText = "select * from dt_students";
            helper.Open();
            return helper.ReadTable();
        }
    }

    public System.Data.DataTable DeleteStudent(int student_id)
    {
        using (MySqlHelper helper = new MySqlHelper())
        {
            helper.Command.CommandText = "delete from dt_students where stid=?stid";
            helper.AddParameter("?stid", MySqlDbType.Int32, student_id);
            helper.Open();
            helper.ExecuteNoneQuery();
            helper.Command.Parameters.Clear();
            helper.Command.CommandText = "select * from dt_students";
            return helper.ReadTable();
        }
    }

    public System.Data.DataTable AddStudent(string studentname, string stu_class)
    {
        using (MySqlHelper helper = new MySqlHelper())
        {
            helper.Command.CommandText = "insert into dt_students(student_name,class)values(?student_name,?class)";
            helper.AddParameter("?student_name", MySqlDbType.VarChar, 255, studentname);
            helper.AddParameter("?class", MySqlDbType.VarChar, 255, stu_class);
            helper.Open();
            helper.ExecuteNoneQuery();
            helper.Command.Parameters.Clear();
            helper.Command.CommandText = "select * from dt_students";
            return helper.ReadTable();
        }
    }
}