﻿using System;
using System.Collections.Generic;
using System.Web;

public class AccessHelper:www.dbhelper.org.SqlHelper.AccessHelper
{
    static readonly string db_path = get_dbpath();

    private static string get_dbpath()
    {
        return HttpContext.Current.Server.MapPath("~/App_Data/db.mdb");
    }

    public override string AccessFPath
    {
        get
        {
            return db_path;
        }
        set
        {
            throw new Exception("NO SET!");
        }
    }


	public AccessHelper():base()
	{

	}
}