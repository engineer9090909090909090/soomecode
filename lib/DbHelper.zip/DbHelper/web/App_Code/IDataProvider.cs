﻿using System;
using System.Data;

public interface IDataProvider
{
    DataTable ReadStudent();
    DataTable DeleteStudent(int student_id);
    DataTable AddStudent(string studentname,string stu_class);
}