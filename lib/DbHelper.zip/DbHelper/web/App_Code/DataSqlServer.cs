﻿using System;
using System.Collections.Generic;
using System.Web;
using www.dbhelper.org.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;

public class DataSqlServer: IDataProvider
{
    public System.Data.DataTable ReadStudent()
    {
        using (SqlServerHelper helper = new SqlServerHelper())
        {
            helper.Command.CommandText = "select * from [Students]";
            helper.Open();
            return helper.ReadTable();
        }
    }

    public System.Data.DataTable DeleteStudent(int student_id)
    {
        using (SqlServerHelper helper = new SqlServerHelper())
        {
            helper.Command.CommandText = "delete from [Students] where stid=@stid";
            helper.AddParameter("@stid", SqlDbType.Int, student_id);
            DbTransaction tran = helper.Connection.BeginTransaction();
            helper.Command.Transaction=tran;
            try
            {
                helper.Open();
                helper.ExecuteNoneQuery();
                tran.Rollback();
            }
            catch { tran.Rollback(); throw; }
            helper.Command.Parameters.Clear();
            helper.Command.CommandText = "select * from [Students]";
            return helper.ReadTable();
        }
    }

    public System.Data.DataTable AddStudent(string studentname, string stu_class)
    {
        using (SqlServerHelper helper = new SqlServerHelper())
        {
            DbTransaction tran = helper.Connection.BeginTransaction();
            helper.Command.Transaction = tran;
            try
            {
                helper.Command.CommandText = "insert into [Students]([student_name],[class])values(@student_name,@class)";
                helper.AddParameter("@student_name", SqlDbType.VarChar, 255, studentname);
                helper.AddParameter("@class", SqlDbType.VarChar, 255, stu_class);
                helper.Open();
                helper.ExecuteNoneQuery();
                tran.Commit();
            }
            catch
            {
                tran.Rollback(); throw;
            }
            helper.Command.Transaction = null;
            helper.Command.Parameters.Clear();
            helper.Command.CommandText = "select * from [Students]";
            return helper.ReadTable();
        }
    }
}